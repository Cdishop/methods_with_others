Project folder for Christopher data management example.
- Last adjusted August 10th, 2020

# Project Purpose

Assess the relationship between general self efficacy and higher order need strength

# What each folder contains:

1) data

Various data files used throughout the project

2) cleaning

R scripts used to clean the data

3) analysis

R scripts used to analyze the data

4) reports

The final paper and presentation stored here